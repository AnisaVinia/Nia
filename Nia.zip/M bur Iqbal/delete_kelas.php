<?php
require_once "config.php";

if (isset($_GET["id"]) && !empty($_GET["id"])) {
    $id = $_GET["id"];

    $sql = "DELETE FROM biodata_kelas WHERE id = ?";

    if ($stmt = mysqli_prepare($link, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        $param_id = $id;

        if (mysqli_stmt_execute($stmt)) {
            header("location: tampil_data_kelas.php");
            exit();
        } else {
            echo "Terjadi kesalahan. Silakan coba lagi.";
        }

        mysqli_stmt_close($stmt);
    }

    mysqli_close($link);
} else {
    header("location: error.php");
    exit();
}
?>

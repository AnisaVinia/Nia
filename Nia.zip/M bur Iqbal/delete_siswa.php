<?php
require_once "config.php";

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $sql = "DELETE FROM biodata_siswa WHERE id=$id";

    if(mysqli_query($link, $sql)){
        header("location: tampil_data.php");
        exit();
    } else {
        echo "Gagal menghapus data.";
    }
}
mysqli_close($link);
?>

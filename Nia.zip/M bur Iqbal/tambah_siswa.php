<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tambah Siswa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Tambah Siswa Baru</h2>
                <form action="proses_tambah_siswa.php" method="post">
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Alamat</label>
                        <textarea name="alamat" class="form-control" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Hobi</label>
                        <input type="text" name="hobi" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Cita-cita</label>
                        <input type="text" name="cita_cita" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Jumlah Saudara</label>
                        <input type="number" name="jumlah_saudara" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>ID Kelas</label>
                        <input type="text" name="id_kelas" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>ID Agama</label>
                        <input type="text" name="id_agama" class="form-control">
                    </div>
                    <input type="submit" class="btn btn-primary" value="Simpan">
                    <a href="tampil_data.php" class="btn btn-default">Kembali</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

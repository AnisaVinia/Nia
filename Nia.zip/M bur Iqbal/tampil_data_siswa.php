<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Siswa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Data Siswa</h2>
                <a href="tambah_siswa.php" class="btn btn-success">Tambah Siswa Baru</a>
                <br><br>
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Tempat Lahir</th>
                            <th>Tanggal Lahir</th>
                            <th>Alamat</th>
                            <th>Hobi</th>
                            <th>Cita-cita</th>
                            <th>Jumlah Saudara</th>
                            <th>ID Kelas</th>
                            <th>ID Agama</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require_once "config.php";

                        $sql = "SELECT * FROM biodata_siswa";
                        $result = mysqli_query($link, $sql);

                        if ($result && mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $row['id'] . "</td>";
                                echo "<td>" . $row['nama'] . "</td>";
                                echo "<td>" . $row['tempat_lahir'] . "</td>";
                                echo "<td>" . $row['tanggal_lahir'] . "</td>";
                                echo "<td>" . $row['alamat'] . "</td>";
                                echo "<td>" . $row['hobi'] . "</td>";
                                echo "<td>" . $row['cita_cita'] . "</td>";
                                echo "<td>" . $row['jumlah_saudara'] . "</td>";
                                echo "<td>" . $row['id_kelas'] . "</td>";
                                echo "<td>" . $row['id_agama'] . "</td>";
                                echo "<td>";
                                echo "<a href='update_siswa.php?id=" . $row['id'] . "' class='btn btn-primary'>Edit</a>";
                                echo "<a href='hapus_siswa.php?id=" . $row['id'] . "' class='btn btn-danger'>Delete</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='11'>Tidak ada data yang ditemukan</td></tr>";
                        }

                        mysqli_close($link);
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>

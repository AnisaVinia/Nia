<?php
require_once "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $kelas = $_POST["kelas"];
    $kompetensi = $_POST["kompetensi"];
    $tahun_pelajaran = $_POST["tahun_pelajaran"];
    $keterangan = $_POST["keterangan"];

    $sql = "UPDATE biodata_kelas SET kelas=?, kompetensi=?, tahun_pelajaran=?, keterangan=? WHERE id=?";

    if ($stmt = mysqli_prepare($link, $sql)) {
        mysqli_stmt_bind_param($stmt, "ssssi", $param_kelas, $param_kompetensi, $param_tahun_pelajaran, $param_keterangan, $param_id);
        $param_kelas = $kelas;
        $param_kompetensi = $kompetensi;
        $param_tahun_pelajaran = $tahun_pelajaran;
        $param_keterangan = $keterangan;
        $param_id = $id;

        if (mysqli_stmt_execute($stmt)) {
            header("location: tampil_data_kelas.php");
            exit();
        } else {
            echo "Terjadi kesalahan. Silakan coba lagi.";
        }

        mysqli_stmt_close($stmt);
    }

    mysqli_close($link);
} else {
    if (isset($_GET["id"]) && !empty(trim($_GET["id"]))) {
        $id = trim($_GET["id"]);

        $sql = "SELECT * FROM biodata_kelas WHERE id = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "i", $param_id);
            $param_id = $id;

            if (mysqli_stmt_execute($stmt)) {
                $result = mysqli_stmt_get_result($stmt);

                if (mysqli_num_rows($result) == 1) {
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    $kelas = $row["kelas"];
                    $kompetensi = $row["kompetensi"];
                    $tahun_pelajaran = $row["tahun_pelajaran"];
                    $keterangan = $row["keterangan"];
                } else {
                    header("location: error.php");
                    exit();
                }
            } else {
                echo "Terjadi kesalahan. Silakan coba lagi.";
            }

            mysqli_stmt_close($stmt);
        }

        mysqli_close($link);
    } else {
        header("location: error.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Data Kelas</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <!-- Style lainnya -->
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Edit Data Kelas</h2>
                    </div>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <div class="form-group">
                            <label>Kelas</label>
                            <input type="text" name="kelas" class="form-control" value="<?php echo $kelas; ?>">
                        </div>
                        <div class="form-group">
                            <label>Kompetensi</label>
                            <input type="text" name="kompetensi" class="form-control" value="<?php echo $kompetensi; ?>">
                        </div>
                        <div class="form-group">
                            <label>Tahun Pelajaran</label>
                            <input type="text" name="tahun_pelajaran" class="form-control" value="<?php echo $tahun_pelajaran; ?>">
                        </div>
                        <div class="form-group">
                            <label>Keterangan</label>
                            <input type="text" name="keterangan" class="form-control" value="<?php echo $keterangan; ?>">
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="tampil_data_kelas.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>

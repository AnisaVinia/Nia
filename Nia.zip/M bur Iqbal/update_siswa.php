<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Data Siswa</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2>Update Data Siswa</h2>
                <?php
                require_once "config.php";

                if(isset($_GET['id'])){
                    $id = $_GET['id'];
                    $sql = "SELECT * FROM biodata_siswa WHERE id=$id";
                    $result = mysqli_query($link, $sql);

                    if(mysqli_num_rows($result) == 1){
                        $row = mysqli_fetch_assoc($result);
                        ?>
                        <form action="proses_update.php" method="post">
                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                            <div class="form-group">
                                <label>Nama</label>
                                <input type="text" name="nama" class="form-control" value="<?php echo $row['nama']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Tempat Lahir</label>
                                <input type="text" name="tempat_lahir" class="form-control" value="<?php echo $row['tempat_lahir']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Tempat Lahir</label>
                                <input type="text" name="tempat_lahir" class="form-control" value="<?php echo $row['tempat_lahir']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Tanggal Lahir</label>
                                <input type="date" name="tempat_lahir" class="form-control" value="<?php echo $row['tanggal_lahir']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Alamat</label>
                                <input type="text" name="alamat" class="form-control" value="<?php echo $row['alamat']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Hobi</label>
                                <input type="text" name="hobi" class="form-control" value="<?php echo $row['hobi']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Cita-Cita</label>
                                <input type="text" name="cita_cita" class="form-control" value="<?php echo $row['cita_cita']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Jumlah Saudara</label>
                                <input type="text" name="jumlah_saudara" class="form-control" value="<?php echo $row['jumlah_saudara']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Id Kelas</label>
                                <input type="text" name="id_kelas" class="form-control" value="<?php echo $row['id_kelas']; ?>">
                            </div><div class="form-group">
                                <label>Id Agama</label>
                                <input type="text" name="id_adama" class="form-control" value="<?php echo $row['id_agama']; ?>">
                            </div>
                            <input type="submit" class="btn btn-primary" value="Simpan">
                            <a href="tampil_data.php" class="btn btn-default">Kembali</a>
                        </form>
                        <?php
                    } else {
                        echo "Data tidak ditemukan.";
                    }
                }
                mysqli_close($link);
                ?>
            </div>
        </div>
    </div>
</body>
</html>
